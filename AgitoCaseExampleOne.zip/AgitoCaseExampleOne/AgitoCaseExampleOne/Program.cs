﻿using System;

namespace AgitoCaseExampleOne
{
    class Program
    {

        static void Main(string[] args)
        {
            #region 9 büyüklüğündeki diziyi oluştur
            int[] array = new int[9];
            #endregion
            #region Random Fonksiyonunun sayacını oluştur
            int count = 0;
            #endregion
            #region Oluşturulan diziye deger atamak için çağırma
            for (int i = 0; i < array.Length; i++)
            {
                count = AssignValueToArray(array, i, ref count);
            }
            Console.Write(" Random fonksiyonu {0} kere çalışmıştır.", count);

            #endregion
        }
        #region Diziye deger ata
        static int AssignValueToArray(int[] array, int indis, ref int count)
        {
            count++;
            var rand = GenerateRandomNumbersFromOneToNine();
            if (IsThereTheSameNumberInTheArray(array, rand))
            {
                AssignValueToArray(array, indis, ref count);
            }
            else
            {
                array[indis] = rand;
                if (indis == array.Length - 1)
                {
                    Console.Write(array[indis]);
                }
                else
                {
                    Console.Write(array[indis] + ",");
                }
            }
            return count;
        }
        #endregion  

        #region Dizimde yeni oluşturulan random sayıdan var mı?
        static bool IsThereTheSameNumberInTheArray(int[] array, int rand)
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == rand)
                {
                    return true;
                }
            }
            return false;
        }
        #endregion

        #region 1,9 arasında random sayı oluştur
        static int GenerateRandomNumbersFromOneToNine()
        {
            Random rnd = new Random();
            return rnd.Next(1, 10);
        }
        #endregion


    }
}
